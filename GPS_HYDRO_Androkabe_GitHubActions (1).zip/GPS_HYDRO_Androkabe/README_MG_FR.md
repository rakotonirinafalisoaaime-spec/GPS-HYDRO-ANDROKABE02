# GPS HYDRO – Androkabe

Prototype Android natif en Kotlin pour OUKITEL G3 / Android 15.

## Fonctions incluses
- GPS : latitude, longitude, altitude et précision
- Enregistrement local SQLite, sans Internet
- Groupes 01 et 02 et catégories hydroélectriques
- Historique des points
- Carte OpenStreetMap avec marqueurs
- Export CSV ouvrable dans Excel et KML

## Compilation
1. Installer Android Studio sur un ordinateur.
2. Décompresser le ZIP et ouvrir le dossier dans Android Studio.
3. Laisser Gradle télécharger les dépendances (Internet nécessaire pour cette étape).
4. Brancher le téléphone, autoriser le débogage USB, puis cliquer sur Run.
5. Pour générer l'APK : Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important
Le GPS et la base locale fonctionnent hors ligne. Les fonds OpenStreetMap nécessitent Internet pour télécharger les tuiles initiales ; les zones déjà mises en cache peuvent rester visibles hors ligne. Pour une vraie carte hors ligne garantie, il faudra ajouter un pack cartographique téléchargé à l'avance.
Ce prototype doit être compilé et testé sur le terrain avant utilisation opérationnelle.


## Compilation APK avec GitHub Actions (sans Android Studio)
1. Créer un dépôt GitHub et téléverser le contenu de ce dossier (le dossier `.github` inclus).
2. Ouvrir l'onglet **Actions** du dépôt.
3. Choisir **Build GPS HYDRO APK**, puis **Run workflow**.
4. Attendre la fin du travail (statut vert).
5. Dans le résultat du workflow, ouvrir **Artifacts** et télécharger `GPS-HYDRO-Androkabe-debug`.
6. Décompresser l'archive téléchargée : elle contient `app-debug.apk`. Ouvrir ce fichier sur le téléphone pour installer l'application.

Le premier build nécessite Internet pour télécharger Gradle et les dépendances Android.
